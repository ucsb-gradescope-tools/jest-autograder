package edu.ucsb.gradescope.example;

public class InvalidAnimalParameterException extends RuntimeException {
}
